from django.contrib import admin

from kex.booking.models import Booking

admin.site.register(Booking)
